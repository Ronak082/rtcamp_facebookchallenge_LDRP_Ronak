<?php 
session_destroy();
echo "<script type='text/javascript'>window.location('http://localhost/RTcamp/index.php')</script>";
 ?>