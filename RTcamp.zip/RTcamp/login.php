<?php  

session_start();
require 'Facebook/autoload.php';
$fb = new Facebook\Facebook([
	// put your data
  'app_id' => '', // Replace {app-id} with your app id
  'app_secret' => '',
  'default_graph_version' => 'v2.2',
  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email','public_profile','user_likes','user_photos','user_friends']; // Optional permissions
$loginUrl = $helper->getLoginUrl('http://localhost/RTcamp/callback.php', $permissions);

header("location:" .$loginUrl);
?>