Google-Drive-PHP-API-Simple-App-Example
=======================================

A very simple File Upload to Google Drive app sample powered with PHP.

This is the source code I have developed to write the article "Subiendo archivos a Google Drive con PHP" available at http://www.eduardocasas.com/blog/05-12-2012/subiendo-archivos-a-google-drive-con-php